
##########################################
# 環境変数設定
##########################################
unset http_proxy
unset FTP_PROXY
unset ftp_proxy
unset HTTPS_PROXY
unset https_proxy
unset no_proxy
unset HTTP_PROXY


##########################################
# Parameters
##########################################
Host="exastro-it-automation"
Port="443"
User="administrator"
Pswd="omcsomcsomcs"

Proxy="http://proxygate2.nic.nec.co.jp:8080/"
Menu="2100000302"

Method="POST"
XCommand="EDIT"
Content="{\"0\":{\"0\":\"登録\",\"3\":\"test_os1\",\"4\":\"●\"}}"



##########################################
# 実行開始
##########################################
echo "["`date +"%Y-%m-%d %H:%M:%S"`'] ######## Execute ########'

Authoriz=`echo "${User}:${Pswd}" | base64`
Url="https://${Host}/default/menu/07_rest_api_ver1.php?no=${Menu}"

echo "["`date +"%Y-%m-%d %H:%M:%S"`"]   Content : " ${Content}

##########################################
# RestAPI(Execute)
##########################################
ResultStr=`curl -H "Host: "${Host}:${Port} \
                -H "Authorization: "${Authoriz} \
                -H "X-Command: "${XCommand} \
                -H "Content-type: application/json" \
                -X ${Method} \
                -d ${Content} \
                -Ssf \
                -k \
                --noproxy ${Proxy} \
                ${Url} | \
                python -c 'from sys import stdin; import sys; import codecs; sys.stdout = codecs.getwriter("utf8")(sys.stdout); print stdin.readline().decode("unicode-escape");'`

echo "["`date +"%Y-%m-%d %H:%M:%S"`'] [Rest API Response Data]'
echo "["`date +"%Y-%m-%d %H:%M:%S"`"]" ${ResultStr}

